advancement revoke @s only infinity_cave:kill/rocklops

execute as @n[type=item_display,tag=aj.infinity_cave.root] run function animated_java:infinity_cave/animations/animation.model.death/play