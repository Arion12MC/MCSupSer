execute if predicate {"condition":"minecraft:inverted","term":{"condition":"minecraft:entity_properties","entity":"this","predicate":{"vehicle":{}}}} run function infinity_cave:ai/rocklops/death

execute unless score @s aj.is_rig_loaded matches 1 run function #animated_java:global/root/on_load
execute if entity @s[tag=aj.infinity_cave.animation.animation.model.arms.playing] run function animated_java:infinity_cave/animations/animation.model.arms/zzz/on_tick
execute if entity @s[tag=aj.infinity_cave.animation.animation.model.pound.playing] run function animated_java:infinity_cave/animations/animation.model.pound/zzz/on_tick
execute if entity @s[tag=aj.infinity_cave.animation.animation.model.death.playing] run function animated_java:infinity_cave/animations/animation.model.death/zzz/on_tick
execute on passengers if entity @s[tag=aj.infinity_cave.data] run function animated_java:infinity_cave/root/zzz/1
execute at @s on passengers run tp @s ~ ~ ~ ~ ~