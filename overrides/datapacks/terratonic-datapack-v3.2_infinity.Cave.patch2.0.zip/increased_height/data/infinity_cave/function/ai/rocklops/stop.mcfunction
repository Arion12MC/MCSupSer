scoreboard players set @s ic.ai 0

execute on passengers if entity @s[type=item_display] run function animated_java:infinity_cave/animations/animation.model.arms/stop