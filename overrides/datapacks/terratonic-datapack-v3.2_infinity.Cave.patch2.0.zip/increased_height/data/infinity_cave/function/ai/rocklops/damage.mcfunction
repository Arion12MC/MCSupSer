$execute positioned ~ ~-4.5 ~ as @e[type=#infinity_cave:all_living,team=!ic.mob_team,distance=..9] run damage @s $(dmg) infinity_cave:bypass by @n[type=creeper,tag=ic.rocklops]

playsound item.mace.smash_ground_heavy hostile @a[distance=..15] ~ ~-3 ~ 1 0 1

particle dust_plume ~ ~-3 ~ 4.5 0.5 4.5 0 400 force
particle trial_spawner_detection ~ ~-3 ~ 1 0 1 0.5 100 force