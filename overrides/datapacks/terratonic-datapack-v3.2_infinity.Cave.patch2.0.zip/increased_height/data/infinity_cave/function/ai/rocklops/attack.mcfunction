execute on passengers if entity @s[type=item_display] run function animated_java:infinity_cave/animations/animation.model.pound/play

playsound minecraft:entity.breeze.charge hostile @a[distance=..20] ~ ~ ~ 1 0 1

effect give @s slowness 2 255 true