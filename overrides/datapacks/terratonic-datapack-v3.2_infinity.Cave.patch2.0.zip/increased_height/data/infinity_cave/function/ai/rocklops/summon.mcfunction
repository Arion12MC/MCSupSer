$summon text_display ~ ~ ~ {CustomNameVisible:1b,Tags:["ic.check"],billboard:"center",see_through:1b,CustomName:'[$(tier),"$(Name)"]'}

data modify storage ic:data mob.id set value 'rocklops'

function animated_java:infinity_cave/summon/rocklops with storage ic:data mob

ride @n[type=text_display,tag=ic.check] mount @n[type=item_display,tag=aj.infinity_cave.root]
