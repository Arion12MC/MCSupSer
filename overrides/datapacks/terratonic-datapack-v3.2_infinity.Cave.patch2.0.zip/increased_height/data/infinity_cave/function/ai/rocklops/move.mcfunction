execute store result score @s ic.rotation run data get entity @s Rotation[0]

scoreboard players operation @s ic.rotation += #ic90 ic.const 

execute on passengers if entity @s[type=item_display] store result entity @s Rotation[0] float 1 run scoreboard players get @n[type=creeper] ic.rotation

execute unless score @s ic.ai matches 1.. on passengers if entity @s[type=item_display] run function animated_java:infinity_cave/animations/animation.model.arms/play

execute if predicate {"condition":"minecraft:entity_properties","entity":"this","predicate":{"periodic_tick":10}} run playsound block.netherite_block.step hostile @a[distance=..15] ~ ~ ~ 0.25 0.5 1

scoreboard players add @s ic.ai 1

scoreboard players set @s[scores={ic.ai=40..}] ic.ai 0