execute on passengers run kill @s
kill @s

playsound block.respawn_anchor.deplete hostile @a[distance=..15] ~ ~ ~ 0.5 2 1