execute store result storage ic:rocklops dmg double 1 run attribute @s generic.attack_damage get

function infinity_cave:ai/rocklops/damage with storage ic:rocklops