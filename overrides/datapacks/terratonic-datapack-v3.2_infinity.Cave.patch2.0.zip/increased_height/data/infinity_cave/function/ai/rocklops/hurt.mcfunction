data modify entity @s active_effects[{id:"minecraft:unluck"}].show_particles set value 0b
execute on passengers on passengers run data modify entity @s item.id set value 'minecraft:red_dye'