execute as @e[type=area_effect_cloud,tag=ic.fireball_damage] at @s run function infinity_cave:abilities/magician/fireball/fireball_damage

execute if score #magician_active ic.int matches 1 run schedule function infinity_cave:abilities/second 10t replace