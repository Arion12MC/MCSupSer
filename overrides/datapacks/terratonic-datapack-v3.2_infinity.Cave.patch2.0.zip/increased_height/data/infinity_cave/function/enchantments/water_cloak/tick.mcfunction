scoreboard players add #wave ic.int 1

function infinity_cave:particles/wave/l1/l1_0
scoreboard players remove @s ic.animate 1
execute if score @s ic.animate matches ..-1 run scoreboard players set @s ic.animate 40

execute as @e[type=#infinity_cave:all_living,tag=!ic.water_cloak,distance=..4] run function infinity_cave:enchantments/water_cloak/damage with entity @n[type=item,tag=ic.water_cloak]