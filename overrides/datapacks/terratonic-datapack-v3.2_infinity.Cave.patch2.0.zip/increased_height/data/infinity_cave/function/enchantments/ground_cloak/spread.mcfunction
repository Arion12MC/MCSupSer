$execute at @p[tag=ic.ground_cloak] positioned ~ ~1 ~ run spreadplayers ~ ~ 0 8 under $(y) false @s

playsound minecraft:block.grass.break player @a[distance=..10] ~ ~ ~ 0.5 0.1 1

execute as @e[distance=..4,type=#infinity_cave:all_living,tag=!ic.ground_cloak] run function infinity_cave:enchantments/ground_cloak/damage with entity @n[type=area_effect_cloud,tag=ic.ground_cloak]

particle block{block_state:"minecraft:dirt"} ~ ~0.051 ~ 1.8 0 1.8 0 25 normal @a