tp ^ ^-1 ^1.1 
data modify storage ic:water_cloak Motion set from entity @s Pos
kill @s