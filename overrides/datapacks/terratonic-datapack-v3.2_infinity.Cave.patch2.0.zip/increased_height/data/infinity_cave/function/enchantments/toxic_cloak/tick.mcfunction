scoreboard players add #toxic_cloud ic.int 1

particle dust_color_transition{from_color:[0.180,0.176,0.176],scale:1,to_color:[0.098,0.522,0.051]} ~ ~ ~ 0.75 0.75 0.75 0 50 force

execute as @e[type=#infinity_cave:all_living,tag=!ic.toxic_cloak,distance=..4] run function infinity_cave:enchantments/toxic_cloak/damage with entity @n[type=item,tag=ic.toxic_cloak]