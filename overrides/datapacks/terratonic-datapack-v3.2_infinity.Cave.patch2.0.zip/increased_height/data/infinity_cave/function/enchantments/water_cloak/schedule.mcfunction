execute as @e[type=item,tag=ic.water_cloak] at @s run function infinity_cave:enchantments/water_cloak/tick

execute unless score #wave ic.int matches 30.. run schedule function infinity_cave:enchantments/water_cloak/schedule 1t