data modify storage ic:wind_cloak owner set from entity @s UUID

summon item_display ~ ~ ~ {UUID:[I;0,0,0,1],view_range:0f,width:0f,height:0f,item:{id:"minecraft:player_head",count:1}}
item modify entity 0-0-0-0-1 container.0 {function:fill_player_head,entity:this}
data modify storage ic:wind_cloak id set from entity 0-0-0-0-1 item.components.minecraft:profile.name
kill 0-0-0-0-1

execute summon wolf run function infinity_cave:enchantments/wind_cloak/set_owner with storage ic:wind_cloak

function infinity_cave:enchantments/wind_cloak/tick