scoreboard players set @s ic.water_cloak 0
playsound entity.player.splash hostile @a[distance=..15] ~ ~ ~ 1 0.5 1

execute in overworld positioned 0.0 0 0.0 summon marker run function infinity_cave:enchantments/water_cloak/apply_motion

summon item_display ~ ~ ~ {UUID:[I;0,0,0,1],view_range:0f,width:0f,height:0f,item:{id:"minecraft:player_head",count:1}}
item modify entity 0-0-0-0-1 container.0 {function:fill_player_head,entity:this}
data modify storage ic:water_cloak id set from entity 0-0-0-0-1 item.components.minecraft:profile.name
kill 0-0-0-0-1

data modify storage ic:water_cloak Rotation set from entity @s Rotation

scoreboard players set #wave ic.int 0

function infinity_cave:enchantments/water_cloak/set with storage ic:water_cloak

schedule function infinity_cave:enchantments/water_cloak/schedule 1t replace

advancement revoke @s only infinity_cave:enchantments/water_cloak