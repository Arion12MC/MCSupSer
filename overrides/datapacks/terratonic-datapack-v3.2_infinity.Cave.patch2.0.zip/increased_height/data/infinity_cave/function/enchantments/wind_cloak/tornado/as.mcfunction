$execute if score $difficulty ic.int matches 1 run damage @s 5 minecraft:mob_attack by $(CustomName)
$execute if score $difficulty ic.int matches 2 run damage @s 7.5 minecraft:mob_attack by $(CustomName)
$execute if score $difficulty ic.int matches 3 run damage @s 10 minecraft:mob_attack by $(CustomName)
