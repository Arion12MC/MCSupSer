scoreboard players set @s ic.ground_cloak 0
tag @s remove ic.ground_cloak