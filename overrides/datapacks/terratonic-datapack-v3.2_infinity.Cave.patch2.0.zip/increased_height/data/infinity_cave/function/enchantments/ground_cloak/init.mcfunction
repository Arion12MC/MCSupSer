scoreboard players set @s ic.ground_cloak 1
tag @s add ic.ground_cloak

execute store result storage ic:ground_cloak y int 1 run data get entity @s Pos[1]

summon item_display ~ ~ ~ {UUID:[I;0,0,0,1],view_range:0f,width:0f,height:0f,item:{id:"minecraft:player_head",count:1}}
item modify entity 0-0-0-0-1 container.0 {function:fill_player_head,entity:this}
data modify storage ic:ground_cloak id set from entity 0-0-0-0-1 item.components.minecraft:profile.name
kill 0-0-0-0-1

execute summon area_effect_cloud run function infinity_cave:enchantments/ground_cloak/set with storage ic:ground_cloak