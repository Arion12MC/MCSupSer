execute if score @s ic.animate matches 8 run function infinity_cave:enchantments/wind_cloak/tornado/frames/f8
execute if score @s ic.animate matches 9 run function infinity_cave:enchantments/wind_cloak/tornado/frames/f9
execute if score @s ic.animate matches 10 run function infinity_cave:enchantments/wind_cloak/tornado/frames/f10
execute if score @s ic.animate matches 11 run function infinity_cave:enchantments/wind_cloak/tornado/frames/f11
execute if score @s ic.animate matches 12 run function infinity_cave:enchantments/wind_cloak/tornado/frames/f12
execute if score @s ic.animate matches 13 run function infinity_cave:enchantments/wind_cloak/tornado/frames/f13
execute if score @s ic.animate matches 14 run function infinity_cave:enchantments/wind_cloak/tornado/frames/f14
execute if score @s ic.animate matches 15 run function infinity_cave:enchantments/wind_cloak/tornado/frames/f15
