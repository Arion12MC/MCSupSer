execute as @n[type=area_effect_cloud,tag=ic.ground_cloak] at @s run function infinity_cave:enchantments/ground_cloak/spread with storage ic:ground_cloak

scoreboard players add @s ic.ground_cloak 1

execute if entity @s[scores={ic.ground_cloak=61..}] run function infinity_cave:enchantments/ground_cloak/stop

advancement revoke @s only infinity_cave:enchantments/ground_cloak