execute as @e[type=wolf,tag=ic.wind_cloak] at @s run function infinity_cave:enchantments/wind_cloak/tornado/animate

schedule function infinity_cave:enchantments/wind_cloak/tick 1t