particle minecraft:firework ~ ~ ~ 0 0 0 0.1 20 force
playsound minecraft:entity.phantom.flap hostile @a[distance=..15] ~ ~ ~ 0.4 2 1
execute at @s as @e[type=#infinity_cave:all_living,distance=..3,tag=!ic.wind_cloak] run function infinity_cave:enchantments/wind_cloak/tornado/as with entity @n[type=wolf,tag=ic.wind_cloak]
