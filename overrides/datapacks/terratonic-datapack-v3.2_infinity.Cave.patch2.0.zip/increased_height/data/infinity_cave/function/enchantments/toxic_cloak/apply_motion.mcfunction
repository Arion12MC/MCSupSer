tp ^ ^ ^0.4 
data modify storage ic:toxic_cloak Motion set from entity @s Pos
kill @s