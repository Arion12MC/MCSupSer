execute as @e[type=item,tag=ic.toxic_cloak] at @s run function infinity_cave:enchantments/toxic_cloak/tick

execute unless score #toxic_cloud ic.int matches 100.. run schedule function infinity_cave:enchantments/toxic_cloak/schedule 1t