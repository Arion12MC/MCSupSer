execute if score @s ic.animate matches 24 run function infinity_cave:enchantments/wind_cloak/tornado/frames/f24
execute if score @s ic.animate matches 25 run function infinity_cave:enchantments/wind_cloak/tornado/frames/f25
execute if score @s ic.animate matches 26 run function infinity_cave:enchantments/wind_cloak/tornado/frames/f26
execute if score @s ic.animate matches 27 run function infinity_cave:enchantments/wind_cloak/tornado/frames/f27
execute if score @s ic.animate matches 28 run function infinity_cave:enchantments/wind_cloak/tornado/frames/f28
execute if score @s ic.animate matches 29 run function infinity_cave:enchantments/wind_cloak/tornado/frames/f29
execute if score @s ic.animate matches 30 run function infinity_cave:enchantments/wind_cloak/tornado/frames/f30
execute if score @s ic.animate matches 31 run function infinity_cave:enchantments/wind_cloak/tornado/frames/f31
